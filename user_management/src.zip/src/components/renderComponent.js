import React from 'react'

export function GridComponent() {



    return (
        // <div id="myGrid" className={getTheme === 'dark' ? "ag-theme-alpine-dark" : "ag-theme-alpine"}
        //     style={{ height: 600, width: 1200, overflow: 'hidden', justifyContent: 'center', marginTop: 15 }}>

        //     <AgGridReact
        //         onGridReady={onGridReady}
        //         style={{ width: '100%', height: '100%' }}
        //         // gridOptions={gridOptions}
        //         alwaysShowHorizontalScroll={true}
        //         pagination={true}
        //         // columnDefs={getColumnDefs}
        //         paginationPageSize="15"
        //         // deltaRowDataMode={true}
        //         frameworkComponents={{
        //             actionCellRenderer: ActionCellRenderer,
        //             actionHeader: actionHeader,
        //             renderdata: renderdata,
        //             renderFirstNameField: renderFirstNameField,
        //             customLoading: customLoading,
        //             customLoadingOverlay: customLoading,
        //         }}
        //         rowData={null}
        //         pagination={true}
        //         loadingOverlayComponent={'customLoadingOverlay'}
        //         defaultColDef={{ resizable: true }} >
        //         {/* <AgGridColumn  field="Images" cellRenderer="ImageShow" sortable={true} filter="agTextColumnFilter"></AgGridColumn> */}
        //         <AgGridColumn field="usr_FName" headerComponent="renderFirstNameField" cellRenderer={fieldRender} sortable={true} filter="agTextColumnFilter"></AgGridColumn>
        //         <AgGridColumn field="usr_LName" cellRenderer={fieldRender} label="Last Name" sortable={true} filter="agTextColumnFilter"></AgGridColumn>
        //         <AgGridColumn field="userName" cellRenderer={fieldRender} label="UserName" sortable={true} filter="agTextColumnFilter"></AgGridColumn>
        //         <AgGridColumn field="email" cellRenderer={fieldRender} sortable={true} filter="agTextColumnFilter"></AgGridColumn>
        //         <AgGridColumn field="mobile" cellRenderer={fieldRender} style={{ width: 1050 }} sortable={true} filter="agTextColumnFilter"></AgGridColumn>
        //         <AgGridColumn field="Action" style={{ width: 300 }} cellRenderer='actionCellRenderer' headerComponent="actionHeader" id={'id'}>
        //         </AgGridColumn>
        //     </AgGridReact>
        // </div>
        <>
        </>
    )
}
