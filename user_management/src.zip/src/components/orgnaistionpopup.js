import React from 'react'

export const  Orgnaistionpopup = ()=> {
  return (
    <div>orgnaistionpopup</div>
  )
}
