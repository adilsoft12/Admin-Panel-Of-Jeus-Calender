import React from 'react';
import {AppConainer} from '../../../components'

export const Report = () => {


    return (
        <AppConainer>
            <h1>reports</h1>
        </AppConainer>
    )
}
