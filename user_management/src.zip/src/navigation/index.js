import React from "react";
import { CommonRouter } from "./CommonRouter";

export const Router = () => {
  return (
    <>
      <CommonRouter />
    </>
  );
};
