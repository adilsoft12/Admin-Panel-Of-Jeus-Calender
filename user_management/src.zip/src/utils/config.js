
const BASE_URL = 'http://o1user-001-site1.dtempurl.com/api/';
const ORBASE_URL = 'http://zewscalender-001-site1.btempurl.com/api'

const _APP_CONFIG = {
    BASE_URL: BASE_URL,
    ORBASE_URL:ORBASE_URL,
};

export const APP_CONFIG = _APP_CONFIG;
